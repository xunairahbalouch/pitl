import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Menu, 
  X, 
  ArrowRight, 
  ChevronRight, 
  Globe, 
  Award, 
  Compass, 
  Users,
  GraduationCap
} from 'lucide-react';
import { cn } from './lib/utils';

// --- Constants ---
const SIGN_UP_URL = "https://docs.google.com/forms/d/e/1FAIpQLSenqmDuM845rFSFTY0-fo3Olo4n1EktlMfcqNG4Kj5XJBM8RA/viewform?usp=header";

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Our Mission', href: '#mission' },
    { name: 'Roadmap', href: '#roadmap' },
    { name: 'Pathways', href: '#pathways' },
  ];

  return (
    <nav className={cn(
      "fixed top-0 left-0 w-full z-50 transition-all duration-500 px-6 py-4 md:px-12",
      isScrolled ? "bg-creme/90 backdrop-blur-md py-3 shadow-sm" : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex-1 hidden lg:flex gap-8 text-[11px] uppercase tracking-[0.2em] font-medium">
          {navLinks.map(link => (
            <a key={link.name} href={link.href} className="hover:text-olive transition-colors">{link.name}</a>
          ))}
        </div>
        
        <div className="flex-1 flex justify-center lg:justify-center">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-olive rounded-sm flex items-center justify-center text-creme font-serif italic text-lg">P</div>
            <h1 className="text-xl md:text-2xl font-serif tracking-tight font-medium hidden sm:block">Pakistan to Ivy Leagues</h1>
          </div>
        </div>

        <div className="flex-1 flex justify-end items-center gap-6">
          <a 
            href={SIGN_UP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:block bg-olive text-creme px-6 py-2.5 rounded-sm text-[11px] uppercase tracking-[0.2em] font-medium hover:bg-ink transition-colors duration-500"
          >
            Sign Up
          </a>
          <button className="lg:hidden" onClick={() => setIsMenuOpen(true)}>
            <Menu size={20} strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 bg-creme z-[60] flex flex-col p-8"
          >
            <div className="flex justify-between items-center mb-12">
              <h1 className="text-2xl font-serif">Pakistan to Ivy Leagues</h1>
              <button onClick={() => setIsMenuOpen(false)}><X size={24} strokeWidth={1} /></button>
            </div>
            <div className="flex flex-col gap-8 text-3xl font-serif italic">
              {navLinks.map(link => (
                <a key={link.name} href={link.href} onClick={() => setIsMenuOpen(false)}>{link.name}</a>
              ))}
              <a 
                href={SIGN_UP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="text-olive underline underline-offset-8"
              >
                Sign Up Now
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen w-full overflow-hidden flex items-center justify-center pt-20 bg-creme">
      <div className="absolute inset-0 z-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
        {/* Stylized Map Outline Placeholder */}
        <Globe size={800} strokeWidth={0.5} className="text-olive" />
      </div>
      
      <div className="relative z-10 text-center px-6 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-6xl md:text-9xl font-serif font-light leading-tight mb-6 text-olive">
            Pakistan to <br /> <span className="italic">Ivy Leagues</span>
          </h2>
          <p className="text-[12px] md:text-[14px] uppercase tracking-[0.4em] font-medium mb-12 opacity-60">
            Your Ivy League Journey Starts Here.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a 
              href={SIGN_UP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-olive text-creme px-10 py-4 rounded-full text-[12px] uppercase tracking-[0.2em] font-medium hover:bg-ink transition-colors duration-500 group flex items-center gap-2"
            >
              Get the Complete Guide
              <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <button className="text-[12px] uppercase tracking-[0.2em] font-medium border-b border-ink/20 pb-1 hover:border-olive transition-colors">
              Explore Roadmap
            </button>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 hidden lg:block">
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center gap-2 opacity-30"
        >
          <span className="text-[10px] uppercase tracking-widest">Scroll</span>
          <div className="w-[1px] h-12 bg-ink" />
        </motion.div>
      </div>
    </section>
  );
};

const MissionSection = () => {
  return (
    <section id="mission" className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div className="space-y-8">
          <span className="text-[11px] uppercase tracking-[0.3em] font-medium text-olive">Our Mission</span>
          <h2 className="text-4xl md:text-6xl font-serif italic leading-tight">Bridging the gap between Pakistan and the world's elite institutions.</h2>
          <p className="text-lg font-serif font-light leading-relaxed opacity-70">
            Pakistan to Ivy Leagues is a dedicated initiative designed to empower high-achieving students across Pakistan. We provide the strategic roadmap, mentorship, and resources necessary to navigate the complex landscape of elite international admissions.
          </p>
          <div className="grid grid-cols-2 gap-8 pt-8">
            <div>
              <h4 className="text-2xl font-serif italic mb-2">100%</h4>
              <p className="text-[10px] uppercase tracking-widest opacity-50">Commitment to Excellence</p>
            </div>
            <div>
              <h4 className="text-2xl font-serif italic mb-2">Global</h4>
              <p className="text-[10px] uppercase tracking-widest opacity-50">Network of Scholars</p>
            </div>
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/5] bg-creme overflow-hidden rounded-2xl">
            <img 
              src="https://picsum.photos/seed/education/800/1000?grayscale" 
              className="w-full h-full object-cover opacity-80"
              alt="Education"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-6 -left-6 bg-olive p-8 text-creme rounded-xl hidden md:block max-w-xs">
            <p className="font-serif italic text-xl">"The journey of a thousand miles begins with a single application."</p>
          </div>
        </div>
      </div>
    </section>
  );
};

interface RoadmapStepProps {
  number: string;
  title: string;
  description: string;
}

const RoadmapStep = ({ number, title, description }: RoadmapStepProps) => (
  <div className="group border-b border-ink/5 py-12 flex flex-col md:flex-row gap-8 md:items-start">
    <span className="text-4xl font-serif italic text-olive opacity-30 group-hover:opacity-100 transition-opacity duration-500">{number}</span>
    <div className="flex-1">
      <h3 className="text-2xl font-serif italic mb-4">{title}</h3>
      <p className="text-sm font-light opacity-60 leading-relaxed max-w-2xl">{description}</p>
    </div>
    <div className="hidden md:block">
      <ChevronRight className="opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-[-10px] group-hover:translate-x-0" />
    </div>
  </div>
);

const Roadmap = () => {
  const steps = [
    { number: "01", title: "Understanding the Ivies", description: "Learn what makes Harvard, Yale, Princeton, and others unique and why they are the pinnacle of global education." },
    { number: "02", title: "Strategic Financial Planning", description: "Navigating need-blind vs need-aware admissions and building an 'arrival fund' for your journey." },
    { number: "03", title: "The Common App Mastery", description: "A complete breakdown of the application portal, from profile building to the crucial personal essay." },
    { number: "04", title: "Impactful Extracurriculars", description: "Moving beyond quantity to quality. How to build passion projects that demonstrate leadership and ownership." },
    { number: "05", title: "Standardized Testing", description: "Navigating the SAT/ACT landscape in a test-optional world and knowing when to submit your scores." },
    { number: "06", title: "The Final Checklist", description: "From recommendation letters to visa preparation, ensuring every detail of your application is polished." },
  ];

  return (
    <section id="roadmap" className="py-32 px-6 md:px-12 bg-creme">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-[11px] uppercase tracking-[0.3em] font-medium text-olive mb-4 block">The Guide</span>
          <h2 className="text-5xl md:text-7xl font-serif italic">Your Roadmap to Success</h2>
        </div>
        <div className="flex flex-col">
          {steps.map((step) => (
            <div key={step.number}>
              <RoadmapStep 
                number={step.number}
                title={step.title}
                description={step.description}
              />
            </div>
          ))}
        </div>
        <div className="mt-20 text-center">
          <a 
            href={SIGN_UP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 text-[12px] uppercase tracking-[0.2em] font-medium border border-olive px-12 py-5 rounded-full hover:bg-olive hover:text-creme transition-all duration-500"
          >
            Download the Complete PDF Guide <BookOpen size={16} />
          </a>
        </div>
      </div>
    </section>
  );
};

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="p-10 bg-white rounded-3xl border border-ink/5 hover:shadow-2xl hover:shadow-olive/5 transition-all duration-700 group">
    <div className="w-12 h-12 bg-creme rounded-2xl flex items-center justify-center mb-8 group-hover:bg-olive group-hover:text-creme transition-colors duration-500">
      <Icon size={24} strokeWidth={1.5} />
    </div>
    <h3 className="text-2xl font-serif italic mb-4">{title}</h3>
    <p className="text-sm opacity-60 leading-relaxed">{description}</p>
  </div>
);

const Pathways = () => {
  return (
    <section id="pathways" className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard 
            icon={Award} 
            title="Scholarships" 
            description="Detailed insights into financial aid packages that cover 100% of demonstrated need for international students."
          />
          <FeatureCard 
            icon={Users} 
            title="Mentorship" 
            description="Connect with Pakistani students already studying at Ivies who can provide first-hand application advice."
          />
          <FeatureCard 
            icon={Compass} 
            title="Strategy" 
            description="Tailored advice for Pakistani curricula (O/A Levels, Matric/FSc) to ensure your academic rigor is recognized."
          />
        </div>
      </div>
    </section>
  );
};

const CTA = () => {
  return (
    <section className="py-32 px-6 bg-olive text-creme">
      <div className="max-w-4xl mx-auto text-center space-y-12">
        <GraduationCap size={64} strokeWidth={1} className="mx-auto opacity-40" />
        <h2 className="text-5xl md:text-7xl font-serif italic leading-tight">Ready to start your Ivy League journey?</h2>
        <p className="text-xl font-serif font-light opacity-70">Join our community of future scholars and get the complete guide to elite admissions.</p>
        <div className="pt-8">
          <a 
            href={SIGN_UP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-creme text-olive px-16 py-6 rounded-full text-[14px] uppercase tracking-[0.2em] font-semibold hover:bg-ink hover:text-creme transition-all duration-500 shadow-xl"
          >
            Sign Up for the Guide
          </a>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-creme pt-32 pb-12 px-6 md:px-12 border-t border-ink/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-24">
          <div className="col-span-1 lg:col-span-2">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-olive rounded-sm flex items-center justify-center text-creme font-serif italic text-xl">P</div>
              <h1 className="text-2xl font-serif tracking-tight font-medium">Pakistan to Ivy Leagues</h1>
            </div>
            <p className="text-sm opacity-60 max-w-sm leading-relaxed mb-8">
              Empowering the next generation of Pakistani leaders through elite global education.
            </p>
          </div>
          
          <div>
            <h4 className="text-[11px] uppercase tracking-[0.2em] font-semibold mb-6">Resources</h4>
            <ul className="space-y-4 text-[13px] opacity-60">
              <li className="hover:opacity-100 cursor-pointer transition-opacity">The Guide</li>
              <li className="hover:opacity-100 cursor-pointer transition-opacity">Roadmap</li>
              <li className="hover:opacity-100 cursor-pointer transition-opacity">Financial Aid</li>
              <li className="hover:opacity-100 cursor-pointer transition-opacity">Mentorship</li>
            </ul>
          </div>

          <div>
            <h4 className="text-[11px] uppercase tracking-[0.2em] font-semibold mb-6">Connect</h4>
            <ul className="space-y-4 text-[13px] opacity-60">
              <li className="hover:opacity-100 cursor-pointer transition-opacity">Instagram</li>
              <li className="hover:opacity-100 cursor-pointer transition-opacity">LinkedIn</li>
              <li className="hover:opacity-100 cursor-pointer transition-opacity">Discord</li>
              <li className="hover:opacity-100 cursor-pointer transition-opacity">Contact Us</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-ink/5 pt-12 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] uppercase tracking-[0.2em] opacity-40">
          <p>© 2024 Pakistan to Ivy Leagues. All rights reserved.</p>
          <div className="flex gap-8">
            <span>Education for All</span>
            <span>Pakistan Zindabad</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen selection:bg-olive selection:text-creme">
      <Navbar />
      <main>
        <Hero />
        <MissionSection />
        <Roadmap />
        <Pathways />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
